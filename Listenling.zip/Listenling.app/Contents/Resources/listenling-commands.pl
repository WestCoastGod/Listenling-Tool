# Usage: /usr/bin/perl listenling-commands.pl /path/to/libListenlingCommands.dylib
# Prints the Now Playing app's supported commands (see ListenlingCommands.m).
use strict;
use warnings;
use DynaLoader;

my $library = shift @ARGV or die "Missing library path\n";
my $handle = DynaLoader::dl_load_file($library, 0) or die "Failed to load $library\n";
my $symbol = DynaLoader::dl_find_symbol($handle, "listenling_commands") or die "Symbol not found\n";
DynaLoader::dl_install_xsub("main::listenling_commands", $symbol);
listenling_commands();
